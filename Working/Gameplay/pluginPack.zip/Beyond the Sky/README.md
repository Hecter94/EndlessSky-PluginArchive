# Beyond the Sky
 Endless Sky plugin expanding advanced alien contents
 
 Currently includes:
 
 -New Quarg warships & outfits:	
 
 -New Pug warship & outfits:	
 
 -Mechanic to adjust fleet strength according to player's strength.
 
 ![fasasadf](https://user-images.githubusercontent.com/19187937/154310420-669961e4-c76b-4095-8340-bc9b86cfdd3a.PNG)
