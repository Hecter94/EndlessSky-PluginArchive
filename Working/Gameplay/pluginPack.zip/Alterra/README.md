# Altera
> A highly WIP plugin currently only adding several clusters east of the Ember-Waste (about 80 systems). The majority of these systems is inhabited by the Alterans, from which you can purchase high level ships and outfits, more or less matching the Heliarch tech level. There isn't really anything else to explore yet.
