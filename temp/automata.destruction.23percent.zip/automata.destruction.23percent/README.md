### automata destruction 23percent <br>
(14 ship attributes changed)(made for 0.10.0) <br>
<br>
Modifies the self destruction chance of Sestor and Mereti ships. <br>
Sestor 349/109/78/71/53/40/27 and Mereti 512/256/128/64/32/16/8 ships have a self destruction value of 0.12 (23%). <br>