### galactic capital investment <br>
(story, repeatable mission)(made for 0.10.1) <br>
<br>
Implements a two mission chain that enables regular spaceport investment opportunities which result in small daily income. Available in human, quarg and hai space with 2 million credits cash. <br>
(inspired by a-alhusaini's investment bank plugin) <br>
<br>
There are mission for 1 million, 5 million, 10 million, 50 million and 100 million credits. When the mission gets triggered(15% chance), the best fitting credit mission starts(your credits + 10%).<br>
1 million = 600 credits daily <br>
5 million = 3.400 credits daily <br>
10 million = 7.200 credits daily <br>
50 million = 37.000 credits daily <br>
100 million = 76.100 credits daily <br>
<br>
These investments pay off after 3,5 to 4,5 years.