### kor efret shipyard <br>
(outfitter and shipyard added)(made for 0.10.0) <br>
<br>
Adds a shipyard with the the three Kor Efret ships(Arch-Carrack, Charm-Shallop, Echo-Galleon) to Laki Nemparu(Kashikt) in Kor Efret space. Also adds an outfitter with all outfits of these three ships. <br>